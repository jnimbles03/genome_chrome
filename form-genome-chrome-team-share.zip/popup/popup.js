// Form Genome Chrome Extension - Popup Script with Batch Analysis

let currentPdfs = [];
let analysisCache = {};

// Scan for PDFs with retry mechanism
async function scanForPdfs(tabId, retries = 3, delay = 100) {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { type: 'SCAN_FOR_PDFS' });

      if (response && response.isPdfPage) {
        // Single PDF mode
        showSinglePdfMode(response.url);
        return;
      } else if (response && response.pdfs && response.pdfs.length > 0) {
        // Multiple PDFs found on page
        showPdfListMode(response.pdfs);
        return;
      } else {
        showNoPdf();
        return;
      }
    } catch (error) {
      // Content script not ready, wait and retry
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // Exponential backoff
      } else {
        // Final attempt failed - content script may not be injected
        showNoPdf();
      }
    }
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  // Load analysis cache from storage
  const cacheData = await chrome.storage.local.get(null);
  analysisCache = cacheData || {};

  // Get current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Request PDF scan from content script with retry mechanism
  await scanForPdfs(tab.id);

  // Set up event listeners
  document.getElementById('selectAll').addEventListener('change', handleSelectAll);
  document.getElementById('analyzeBatch').addEventListener('click', handleBatchAnalysis);
  document.getElementById('analyzeSingle').addEventListener('click', handleSingleAnalysis);
  document.getElementById('clearCache').addEventListener('click', handleClearCache);
  document.getElementById('generateReport').addEventListener('click', () => {
    generateBatchReport(analysisCache, currentPdfs);
  });
  document.getElementById('generateCSV').addEventListener('click', () => {
    generateCSVReport(analysisCache, currentPdfs);
  });
  document.getElementById('openDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
  });
  document.getElementById('openTeamDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/team-dashboard.html') });
  });
});

function showNoPdf() {
  document.getElementById('noPdf').classList.remove('hidden');
  hideAll(['pdfList', 'singlePdf', 'status', 'error', 'results']);
}

function showSinglePdfMode(url) {
  document.getElementById('singlePdf').classList.remove('hidden');
  document.getElementById('currentPdfTitle').textContent = extractFilename(url);
  hideAll(['pdfList', 'noPdf', 'status', 'error']);

  // Check if we have cached analysis
  const cacheKey = `analysis_${hashUrl(url)}`;
  if (analysisCache[cacheKey]) {
    displayResults(analysisCache[cacheKey]);
  }
}

function showPdfListMode(pdfs) {
  currentPdfs = pdfs;
  document.getElementById('pdfList').classList.remove('hidden');
  hideAll(['singlePdf', 'noPdf', 'status', 'error', 'results']);

  renderPdfList();
}

function renderPdfList() {
  const container = document.getElementById('pdfItems');
  container.innerHTML = '';

  currentPdfs.forEach((pdf, index) => {
    const cacheKey = `analysis_${hashUrl(pdf.url)}`;
    const cached = analysisCache[cacheKey];

    // Check if cache is expired (older than 7 days)
    const cacheAge = cached?._cached_at ? Date.now() - cached._cached_at : Infinity;
    const cacheExpired = cacheAge > (7 * 24 * 60 * 60 * 1000); // 7 days in ms

    const isAnalyzed = !!cached && !cacheExpired;
    const hasError = cached?.error;

    const item = document.createElement('div');
    item.className = 'pdf-item';
    item.innerHTML = `
      <input type="checkbox" id="pdf_${index}" data-url="${pdf.url}" ${isAnalyzed ? '' : 'checked'}>
      <div class="pdf-item-info">
        <div class="pdf-item-name" title="${pdf.text}">${pdf.text}</div>
        <div class="pdf-item-status ${isAnalyzed ? 'analyzed' : ''} ${hasError ? 'error' : ''}">
          ${isAnalyzed ? (hasError ? 'Error' : '✓ Analyzed') : 'Not analyzed'}
        </div>
      </div>
      ${isAnalyzed && !hasError ? '<button class="btn-view-results" data-url="' + pdf.url + '">View</button>' : ''}
    `;

    item.querySelector('input[type="checkbox"]').addEventListener('change', updateSelectAllState);

    // Add click handler for "View" button
    const viewBtn = item.querySelector('.btn-view-results');
    if (viewBtn) {
      viewBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const cacheKey = `analysis_${hashUrl(pdf.url)}`;
        displayResults(analysisCache[cacheKey]);
      });
    }

    container.appendChild(item);
  });

  updateSelectAllState();
  updateSelectedCount();
}

function updateSelectAllState() {
  const checkboxes = document.querySelectorAll('.pdf-item input[type="checkbox"]');
  const selectAllCheckbox = document.getElementById('selectAll');
  const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;

  selectAllCheckbox.checked = checkedCount === checkboxes.length;
  selectAllCheckbox.indeterminate = checkedCount > 0 && checkedCount < checkboxes.length;

  updateSelectedCount();
}

function updateSelectedCount() {
  const checkboxes = document.querySelectorAll('.pdf-item input[type="checkbox"]');
  const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
  document.getElementById('selectedCount').textContent = checkedCount;
  document.getElementById('totalCount').textContent = checkboxes.length;
}

function handleSelectAll(event) {
  const checkboxes = document.querySelectorAll('.pdf-item input[type="checkbox"]');
  checkboxes.forEach(cb => {
    cb.checked = event.target.checked;
  });
  updateSelectedCount();
}

async function handleBatchAnalysis() {
  const checkboxes = document.querySelectorAll('.pdf-item input[type="checkbox"]:checked');
  const selectedPdfs = Array.from(checkboxes).map(cb => ({
    url: cb.dataset.url,
    checkbox: cb
  }));

  if (selectedPdfs.length === 0) {
    showError('Please select at least one PDF to analyze');
    return;
  }

  // Show batch status
  document.getElementById('batchStatus').classList.remove('hidden');
  document.getElementById('analyzeBatch').disabled = true;

  let completed = 0;
  const total = selectedPdfs.length;

  for (const pdf of selectedPdfs) {
    updateBatchStatus(completed, total, pdf.url);

    try {
      const result = await analyzePdf(pdf.url);
      const cacheKey = `analysis_${hashUrl(pdf.url)}`;
      // Add timestamp to cached result
      result._cached_at = Date.now();
      analysisCache[cacheKey] = result;
      await chrome.storage.local.set({ [cacheKey]: result });

      // Update UI - re-render the entire list to show View buttons
      completed++;
      updateProgress((completed / total) * 100);

      // Re-render the list to show the View button
      renderPdfList();

    } catch (error) {
      console.error('Analysis failed:', error);
      const cacheKey = `analysis_${hashUrl(pdf.url)}`;
      analysisCache[cacheKey] = { error: error.message };

      completed++;
      updateProgress((completed / total) * 100);

      // Re-render to show error state
      renderPdfList();
    }
  }

  // Complete
  document.getElementById('batchStatus').classList.add('hidden');
  document.getElementById('analyzeBatch').disabled = false;
  updateSelectAllState();
  updateSelectedCount();

  showSuccess(`Analyzed ${completed} PDFs successfully!`);
}

async function handleSingleAnalysis() {
  const url = document.getElementById('currentPdfTitle').textContent;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  showStatus('Analyzing PDF...');

  try {
    const result = await analyzePdf(tab.url);
    const cacheKey = `analysis_${hashUrl(tab.url)}`;
    result._cached_at = Date.now();
    analysisCache[cacheKey] = result;
    await chrome.storage.local.set({ [cacheKey]: result });

    displayResults(result);
  } catch (error) {
    showError(error.message || 'Failed to analyze PDF');
  }
}

function updateBatchStatus(completed, total, currentUrl) {
  const filename = extractFilename(currentUrl);
  document.getElementById('batchStatusText').textContent =
    `Analyzing ${completed + 1} of ${total}: ${filename}`;
}

function updateProgress(percent) {
  document.getElementById('progressFill').style.width = `${percent}%`;
}

async function analyzePdf(pdfUrl) {
  console.log('[FORM GENOME] Starting analysis for:', pdfUrl);

  // Download PDF
  const response = await fetch(pdfUrl);
  if (!response.ok) {
    throw new Error(`Failed to download PDF: ${response.statusText}`);
  }

  const blob = await response.blob();
  console.log('[FORM GENOME] Downloaded PDF, size:', blob.size);

  const formData = new FormData();
  formData.append('file', blob, extractFilename(pdfUrl));

  // Send to Form Genome API
  const apiUrl = `${CONFIG.API_URL}${CONFIG.ANALYZE_ENDPOINT}`;
  console.log('[FORM GENOME] Sending to API:', apiUrl);

  const analysisResponse = await fetch(apiUrl, {
    method: 'POST',
    body: formData
  });

  if (!analysisResponse.ok) {
    throw new Error(`Analysis failed: ${analysisResponse.statusText}`);
  }

  const data = await analysisResponse.json();
  console.log('[FORM GENOME] API Response:', {
    signature_required: data.signature_required,
    signature_count: data.signature_analysis?.signature_count,
    entity: data.entity,
    entity_name: data.entity_name,
    gemini_analyzed: data.gemini_analyzed
  });

  if (!data.ok) {
    throw new Error(data.parse_error || 'Analysis failed');
  }

  return data;
}

function showStatus(message) {
  document.getElementById('status').classList.remove('hidden');
  document.getElementById('statusText').textContent = message;
  hideAll(['error', 'results', 'pdfList', 'singlePdf', 'noPdf']);
}

function showError(message) {
  document.getElementById('error').classList.remove('hidden');
  document.getElementById('errorText').textContent = message;
  document.getElementById('status').classList.add('hidden');

  setTimeout(() => {
    document.getElementById('error').classList.add('hidden');
  }, 5000);
}

function showSuccess(message) {
  // Reuse error element for success messages
  const errorEl = document.getElementById('error');
  errorEl.classList.remove('hidden');
  errorEl.style.background = '#e8f5e9';
  errorEl.style.borderColor = '#a5d6a7';
  document.getElementById('errorText').style.color = '#2e7d32';
  document.getElementById('errorText').textContent = message;

  setTimeout(() => {
    errorEl.classList.add('hidden');
    errorEl.style.background = '';
    errorEl.style.borderColor = '';
    document.getElementById('errorText').style.color = '';
  }, 3000);
}

function displayResults(data) {
  // Debug: Log the actual data received
  console.log('[FORM GENOME] Displaying results:', {
    signature_required: data.signature_required,
    signature_count: data.signature_analysis?.signature_count,
    entity_name: data.entity_name,
    entity: data.entity,
    action_type: data.action_type
  });

  document.getElementById('results').classList.remove('hidden');
  document.getElementById('status').classList.add('hidden');

  // Title - use pretty_title or form_name, not the filename
  document.getElementById('formTitle').textContent = data.pretty_title || data.form_name || data.title || 'Untitled Form';

  // Stats
  document.getElementById('fieldCount').textContent = data.total_field_count || data.field_count || 0;
  document.getElementById('pages').textContent = data.pages || 0;
  document.getElementById('complexity').textContent = data.complexity_score || 0;

  // Details - use entity_name which has the full name
  const entity = data.entity_name || data.entity || 'Unknown';
  document.getElementById('entity').textContent = entity;

  // Show simple action type description
  const actionDesc = data.signature_required ? 'Signature Required' : 'Information Only';
  document.getElementById('actionType').textContent = actionDesc;

  // Show signature requirement clearly
  const sigCount = data.signature_analysis?.signature_count || 0;
  const sigText = data.signature_required
    ? `Yes (${sigCount} signature${sigCount !== 1 ? 's' : ''})`
    : 'No';
  document.getElementById('signatures').textContent = sigText;

  document.getElementById('confidence').textContent =
    `${data.confidence_tier || 'unknown'}`;

  // Badges
  const badgesContainer = document.getElementById('badges');
  badgesContainer.innerHTML = '';

  if (data.gemini_analyzed) {
    addBadge('✓ Gemini Analyzed', 'success');
  }

  if (data.signature_required) {
    addBadge('Signature Required', 'warning');
  }

  if (data.notarization_required) {
    addBadge('Notarization Required', 'warning');
  }

  if (data.attachments_required) {
    addBadge('Attachments Required', 'warning');
  }

  if (data.identification_required) {
    addBadge('ID Required', 'warning');
  }
}

function addBadge(text, type = 'default') {
  const badge = document.createElement('span');
  badge.className = `badge ${type}`;
  badge.textContent = text;
  document.getElementById('badges').appendChild(badge);
}

function hideAll(ids) {
  ids.forEach(id => {
    document.getElementById(id).classList.add('hidden');
  });
}

function extractFilename(url) {
  const urlParts = url.split('/');
  return urlParts[urlParts.length - 1].split('?')[0] || 'document.pdf';
}

function hashUrl(url) {
  let hash = 0;
  for (let i = 0; i < url.length; i++) {
    const char = url.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

async function handleClearCache() {
  if (!confirm('Clear all cached analysis results? You will need to re-analyze PDFs to see their results again.')) {
    return;
  }

  // Clear all storage
  await chrome.storage.local.clear();
  analysisCache = {};

  console.log('[FORM GENOME] Cache cleared! analysisCache is now empty:', analysisCache);

  // Refresh the list
  renderPdfList();

  showSuccess('Cache cleared! Select PDFs to re-analyze them.');
}

// Make clearCache available in console for debugging
window.forceClearCache = async function() {
  await chrome.storage.local.clear();
  analysisCache = {};
  console.log('[FORM GENOME] Force cleared! Reload the popup to see changes.');
};
