// Form Genome Batch Report Generator

function generateBatchReport(analysisCache, currentPdfs) {
  // Filter analyzed PDFs
  const analyzedForms = currentPdfs
    .map(pdf => {
      const cacheKey = `analysis_${hashUrl(pdf.url)}`;
      const data = analysisCache[cacheKey];
      if (data && !data.error && data.ok) {
        return { ...data, pdf_url: pdf.url, pdf_name: pdf.text };
      }
      return null;
    })
    .filter(Boolean);

  if (analyzedForms.length === 0) {
    alert('No analyzed forms found. Please analyze some PDFs first.');
    return;
  }

  // Calculate stats
  const stats = calculateStats(analyzedForms);

  // Generate HTML report
  const reportHTML = generateReportHTML(analyzedForms, stats);

  // Download as HTML file
  downloadReport(reportHTML, stats.entity_name);
}

function generateCSVReport(analysisCache, currentPdfs) {
  // Filter analyzed PDFs
  const analyzedForms = currentPdfs
    .map(pdf => {
      const cacheKey = `analysis_${hashUrl(pdf.url)}`;
      const data = analysisCache[cacheKey];
      if (data && !data.error && data.ok) {
        return { ...data, pdf_url: pdf.url, pdf_name: pdf.text };
      }
      return null;
    })
    .filter(Boolean);

  if (analyzedForms.length === 0) {
    alert('No analyzed forms found. Please analyze some PDFs first.');
    return;
  }

  // Generate CSV content
  const csv = generateCSVContent(analyzedForms);

  // Get entity name for filename
  const entityName = analyzedForms[0]?.entity_name || 'Unknown';

  // Download CSV
  downloadCSV(csv, entityName);
}

function generateCSVContent(forms) {
  // Define all columns we want to export
  const headers = [
    'Form Name',
    'Entity Name',
    'PDF URL',
    'Pages',
    'Total Fields',
    'Complexity Score',
    'NIGO Score',
    'Confidence Tier',
    'Action Type',
    'Signature Required',
    'Signature Count',
    'Notarization Required',
    'Attachments Required',
    'Attachment Count',
    'Payment Required',
    'Payment Amount',
    'Identification Required',
    'Conditional Logic',
    'Third Party Involved',
    'Witnesses Required',
    'Deadlines Present',
    'Form Purpose',
    'Industry Vertical',
    'Industry Subvertical',
    'Estimated Signer Time',
    'Estimated Processing Time'
  ];

  // Helper to escape CSV values
  const escapeCsv = (value) => {
    if (value === null || value === undefined) return '';
    const str = String(value);
    // Escape quotes and wrap in quotes if contains comma, quote, or newline
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  // Build CSV rows
  const rows = [headers.map(escapeCsv).join(',')];

  forms.forEach(form => {
    const row = [
      getFormDisplayName(form),
      form.entity_name || '',
      form.pdf_url || '',
      form.pages || 1,
      form.total_field_count || form.field_count || 0,
      form.complexity_score || 0,
      form.nigo_score || 0,
      form.confidence_tier || '',
      form.action_type || '',
      form.signature_required ? 'Yes' : 'No',
      form.signature_analysis?.signature_count || 0,
      form.notarization_required ? 'Yes' : 'No',
      form.attachments_required ? 'Yes' : 'No',
      form.attachment_count || 0,
      form.payment_required ? 'Yes' : 'No',
      form.payment_amount || '',
      form.identification_required ? 'Yes' : 'No',
      form.conditional_logic ? 'Yes' : 'No',
      form.third_party_involved ? 'Yes' : 'No',
      form.witnesses_required ? 'Yes' : 'No',
      form.deadlines_present ? 'Yes' : 'No',
      form.form_purpose || '',
      form.industry_vertical || '',
      form.industry_subvertical || '',
      form.estimated_signer_time || '',
      form.estimated_processing_time || ''
    ];

    rows.push(row.map(escapeCsv).join(','));
  });

  return rows.join('\n');
}

function downloadCSV(csvContent, entityName) {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `Form_Analysis_${entityName.replace(/[^a-zA-Z0-9]/g, '_')}_${timestamp}.csv`;

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function getFormDisplayName(form) {
  // Comprehensive fallback chain for form display name
  // 1. Try API-provided titles first
  let name = form.pretty_title || form.form_title || form.form_name || form.title;

  // 2. If still empty, try to clean up the pdf_name from link text
  if (!name || name.trim() === '') {
    name = form.pdf_name || 'Untitled';
    // Clean up pdf_name: remove duplicate extensions, clean formatting
    name = name
      .replace(/\.pdf\.pdf$/i, '.pdf')  // Remove duplicate .pdf.pdf
      .replace(/\.pdf$/i, '')             // Remove .pdf extension
      .replace(/^[Gg]forms?/i, '')        // Remove "Gform" or "gform" prefix
      .trim();
  }

  return name || 'Untitled';
}

function calculateStats(forms) {
  const total = forms.length;
  const entityName = forms[0]?.entity_name || 'Unknown Organization';

  // Average complexity
  const avgComplexity = (forms.reduce((sum, f) => sum + (f.complexity_score || 0), 0) / total).toFixed(1);

  // Hardest form
  const hardest = forms.reduce((max, f) =>
    (f.complexity_score || 0) > (max.complexity_score || 0) ? f : max
  , forms[0]);

  // Use pretty_title first, with comprehensive fallback chain
  const hardestName = getFormDisplayName(hardest);

  // Payment total
  const paymentTotal = forms.reduce((sum, f) => sum + (parseFloat(f.payment_amount) || 0), 0);
  const paymentTotalFormatted = paymentTotal > 0
    ? `$${paymentTotal.toLocaleString()}`
    : '—';

  // Calculate all friction metrics
  const frictionMetrics = [
    {
      id: 'attachments',
      title: 'Attachment hunting',
      percentage: ((forms.filter(f => f.attachments_required).length / total) * 100).toFixed(0),
      badge: '% of forms',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M21.44 11.05l-8.49 8.49a6 6 0 11-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.9 9.9a2 2 0 11-2.83-2.83l8.49-8.49"></path></svg>',
      description: 'Chasing proofs (certificates, letters, IDs) across offices is a common derail.'
    },
    {
      id: 'notary',
      title: 'Notary bottlenecks',
      percentage: ((forms.filter(f => f.notarization_required).length / total) * 100).toFixed(0),
      badge: '% require in-person steps',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M9 7a3 3 0 116 0 3 3 0 01-6 0z"></path><path d="M5 22h14"></path><path d="M4 18h16a1 1 0 001-1v-2a4 4 0 00-4-4H7a4 4 0 00-4 4v2a1 1 0 001 1z"></path></svg>',
      description: 'Even small percentages create friction for citizens without easy access to notaries.'
    },
    {
      id: 'conditional',
      title: 'Conditional confusion',
      percentage: ((forms.filter(f => f.conditional_logic).length / total) * 100).toFixed(0),
      badge: '% include branching',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M6 3v6a4 4 0 004 4h4"></path><circle cx="6" cy="3" r="2"></circle><circle cx="14" cy="13" r="2"></circle><circle cx="18" cy="21" r="2"></circle><path d="M14 15v4a2 2 0 002 2"></path></svg>',
      description: '"If this, then that" logic raises error risk and NIGO returns when people misread paths.'
    },
    {
      id: 'pii',
      title: 'High identification burden',
      percentage: ((forms.filter(f => f.identification_required || (f._flags?.pii_hits > 0)).length / total) * 100).toFixed(0),
      badge: '% request ID/PII',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6l7-4z"></path></svg>',
      description: 'Sensitive details create pause and slow completion when citizens don\'t have documents on hand.'
    },
    {
      id: 'signatures',
      title: 'Signature requirements',
      percentage: ((forms.filter(f => f.signature_required).length / total) * 100).toFixed(0),
      badge: '% require signatures',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M3 17h18M3 12h18M3 7h18"></path><path d="M8 21l4-4 4 4"></path></svg>',
      description: 'Manual signatures add friction and delay when not digital-first.'
    },
    {
      id: 'payment',
      title: 'Payment friction',
      percentage: ((forms.filter(f => f.payment_required).length / total) * 100).toFixed(0),
      badge: '% require payment',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="2"></rect><path d="M2 10h20"></path></svg>',
      description: 'Payment requirements add complexity and abandon risk if not streamlined.'
    },
    {
      id: 'complexity',
      title: 'High field density',
      percentage: ((forms.filter(f => (f.total_field_count || f.field_count || 0) > 20).length / total) * 100).toFixed(0),
      badge: '% have 20+ fields',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect></svg>',
      description: 'Forms with many fields increase abandonment and require more time to complete.'
    },
    {
      id: 'pages',
      title: 'Multi-page complexity',
      percentage: ((forms.filter(f => (f.pages || 1) > 3).length / total) * 100).toFixed(0),
      badge: '% have 4+ pages',
      icon: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#C43D00" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z"></path><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"></path></svg>',
      description: 'Lengthy forms create cognitive load and increase the likelihood of errors.'
    }
  ];

  // Sort by percentage descending and take top 4
  const topFrictions = frictionMetrics
    .sort((a, b) => parseFloat(b.percentage) - parseFloat(a.percentage))
    .slice(0, 4);

  return {
    total,
    entity_name: entityName,
    avg_complexity: avgComplexity,
    hardest_name: hardestName,
    hardest_complexity: hardest.complexity_score || 0,
    payment_total: paymentTotalFormatted,
    friction_metrics: topFrictions
  };
}

function generateReportHTML(forms, stats) {
  const timestamp = new Date().toLocaleDateString();

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Form Analysis Report — ${stats.entity_name}</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<style>
:root{ --accent:#0B6E4F; --ink:#222; --muted:#666; --hair:#EAEAEA; --bg:#FAFAFA; --card:#FFFFFF; --warn:#C43D00; --note:#6B7280;
--radius:18px; --shadow: 0 6px 18px rgba(0,0,0,.06); --space: clamp(28px, 5vw, 64px);}
*{box-sizing:border-box} html,body{height:100%}
body{margin:0;font-family:"Inter",system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:var(--ink);background:var(--bg);line-height:1.6;-webkit-font-smoothing:antialiased;}
a{color:inherit} .container{max-width:1440px;margin:0 auto;padding:0 var(--space)} .section{padding: calc(var(--space) * 1.25) 0}
h1{font-size:clamp(38px,6vw,64px);line-height:1.15;margin:0 0 14px 0;font-weight:800;letter-spacing:-0.02em}
h2{font-size:clamp(24px,4vw,32px);margin:0 0 12px 0;font-weight:700;letter-spacing:-0.01em}
.sub{color:var(--muted);max-width:64ch;font-size:clamp(16px,2vw,18px)}
.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:24px}
@media (max-width:720px){.stats{grid-template-columns:repeat(2,1fr)}}
.stat{border:1px solid var(--hair);border-radius:14px;background:#fff;padding:14px 16px;box-shadow:var(--shadow)}
.stat .num{font-weight:800;font-size:clamp(22px,4vw,30px);color:var(--accent);line-height:1.2} .stat .label{font-size:13px;color:var(--note);margin-top:4px}
.hero-card{background:var(--card);border:1px solid var(--hair);border-radius:var(--radius);box-shadow:var(--shadow);padding:clamp(18px,3vw,28px);margin-top:40px;grid-column:1/-1}
.hards{display:grid!important;grid-template-columns:1fr 1fr!important;gap:14px!important;margin-top:6px}
@media (max-width:899.98px){.hards{grid-template-columns:1fr!important}}
.hard{display:flex;gap:12px;align-items:flex-start;border:1px dashed var(--hair);background:#fff;border-radius:14px;padding:14px;min-width:0}
.hard svg{min-width:24px;margin-top:2px} .hard strong{display:block}
.badge{display:inline-block;padding:.25rem .6rem;border-radius:999px;border:1px solid var(--hair);background:#fff;font-size:12px;margin-left:8px}
.note{color: var(--note);font-size:14px;margin-top:2px} .divider{height:1px;background:var(--hair);margin:calc(var(--space)*.75) 0}
.controls{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:14px}
.search{flex:1 1 320px;display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--hair);border-radius:999px;padding:10px 16px}
.search input{width:100%;border:0;outline:0;font-size:15px;background:transparent} .quickfilters{display:flex;gap:10px;flex-wrap:wrap}
.qf{border:1px solid var(--hair);background:#fff;border-radius:999px;padding:8px 12px;font-size:13px;cursor:pointer}
.qf.active{border-color:var(--accent);box-shadow:0 0 0 3px rgba(11,110,79,.12)}
.table-wrap{background:var(--card);border:1px solid var(--hair);border-radius:var(--radius);box-shadow:var(--shadow);overflow:clip}
.table-inner{width:100%;overflow:auto} table{width:100%;border-collapse:collapse;min-width:1200px}
thead th{position:sticky;top:0;z-index:1;background:#fff;border-bottom:1px solid var(--hair);font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#444;padding:12px 14px;text-align:left;cursor:pointer}
tbody td{border-top:1px solid #F3F3F3;padding:12px 14px;vertical-align:top;font-size:14px} tbody tr:hover{background:#F6FFF9}
th.sort-asc::after{content:" ↑";color:#999} th.sort-desc::after{content:" ↓";color:#999}
.formname{font-weight:600;color:#111;font-size:15px} .mini{display:block;height:6px;width:120px;background:#EEE;border-radius:3px}
.mini > span{display:block;height:100%;background:var(--accent);border-radius:3px} .footer{color:#888;font-size:13px;text-align:center;padding:calc(var(--space)*.75) 0}
</style>
</head>
<body>

<div class="section">
  <div class="container">
    <h1>Where customers feel the friction</h1>
    <p class="sub">This report spotlights the moments that make <strong>${stats.entity_name}</strong> forms hard to complete — attachments to chase, occasional notarizations, and conditional questions that raise uncertainty.</p>
    <div class="stats">
      <div class="stat"><div class="num">${stats.total}</div><div class="label">Total forms analyzed</div></div>
      <div class="stat"><div class="num">${stats.avg_complexity}</div><div class="label">Average complexity score</div></div>
      <div class="stat"><div class="num" style="font-size:14px;line-height:1.3">${stats.hardest_name}</div><div class="label">Hardest form</div></div>
      <div class="stat"><div class="num">${stats.payment_total}</div><div class="label">Total payment amounts</div></div>
    </div>

    <div class="hero-card">
      <h2>What makes this hard</h2>
      <div class="hards">
        ${stats.friction_metrics.map(metric => `
        <div class="hard">
          ${metric.icon}
          <div><strong>${metric.title}</strong><span class="badge">${metric.percentage}${metric.badge}</span>
          <div class="note">${metric.description}</div></div>
        </div>
        `).join('')}
      </div>
    </div>
  </div>
</div>

<div class="divider container"></div>

<div class="section">
  <div class="container">
    <div class="controls">
      <div class="search">
        <input id="searchInput" type="search" placeholder="Search by form name..." />
      </div>
      <div class="quickfilters">
        <button class="qf" data-filter="Attachments">Attachments</button>
        <button class="qf" data-filter="Notary">Notary</button>
        <button class="qf" data-filter="Conditional">Conditional</button>
        <button class="qf" data-filter="PII">ID/PII</button>
        <button class="qf" data-filter="Payment">Payment</button>
        <button class="qf" data-reset>Reset</button>
      </div>
    </div>

    <div class="table-wrap">
      <div class="table-inner">
        <table id="allFormsTable">
          <thead>
            <tr>
              <th data-col="form">Form Name</th>
              <th data-col="complexity">Complexity</th>
              <th data-col="nigo">NIGO Score</th>
              <th data-col="notary">Notarization</th>
              <th data-col="attachments">Attachments</th>
              <th data-col="payment">Payment</th>
              <th data-col="signatures">Signatures</th>
              <th data-col="fields">Fields</th>
              <th data-col="pages">Pages</th>
            </tr>
          </thead>
          <tbody>
${generateTableRows(forms)}
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="footer">Generated ${timestamp} from Form Genome analysis • Built with Claude Code</div>

<script>
const data = ${JSON.stringify(forms)};

// Search functionality
document.getElementById('searchInput').addEventListener('input', (e) => {
  const query = e.target.value.toLowerCase();
  const rows = document.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(query) ? '' : 'none';
  });
});

// Filter functionality
document.querySelectorAll('.qf').forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.dataset.filter;
    if (btn.dataset.reset !== undefined) {
      document.querySelectorAll('.qf').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('tbody tr').forEach(row => row.style.display = '');
      return;
    }

    btn.classList.toggle('active');
    const activeFilters = Array.from(document.querySelectorAll('.qf.active')).map(b => b.dataset.filter);

    if (activeFilters.length === 0) {
      document.querySelectorAll('tbody tr').forEach(row => row.style.display = '');
      return;
    }

    document.querySelectorAll('tbody tr').forEach((row, idx) => {
      const form = data[idx];
      let match = false;

      if (activeFilters.includes('Attachments') && form.attachments_required) match = true;
      if (activeFilters.includes('Notary') && form.notarization_required) match = true;
      if (activeFilters.includes('Conditional') && form.conditional_logic) match = true;
      if (activeFilters.includes('PII') && (form.identification_required || (form._flags?.pii_hits > 0))) match = true;
      if (activeFilters.includes('Payment') && form.payment_required) match = true;

      row.style.display = match ? '' : 'none';
    });
  });
});

// Sort functionality
document.querySelectorAll('th[data-col]').forEach(th => {
  th.addEventListener('click', () => {
    const col = th.dataset.col;
    const dir = th.classList.contains('sort-asc') ? 'desc' : 'asc';

    document.querySelectorAll('th').forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
    th.classList.add(\`sort-\${dir}\`);

    const tbody = document.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));

    rows.sort((a, b) => {
      const aIdx = rows.indexOf(a);
      const bIdx = rows.indexOf(b);
      const aVal = data[aIdx][col] || 0;
      const bVal = data[bIdx][col] || 0;

      if (typeof aVal === 'number') {
        return dir === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return dir === 'asc' ? String(aVal).localeCompare(String(bVal)) : String(bVal).localeCompare(String(aVal));
    });

    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
  });
});
</script>
</body>
</html>`;
}

function generateTableRows(forms) {
  return forms.map(f => `
            <tr>
              <td class="formname">${escapeHtml(getFormDisplayName(f))}</td>
              <td>${f.complexity_score || 0}</td>
              <td>${f.nigo_score || 0}</td>
              <td>${f.notarization_required ? '✓ Yes' : '—'}</td>
              <td>${f.attachments_required ? '✓ Yes' : '—'}</td>
              <td>${f.payment_required ? (f.payment_amount ? '$' + f.payment_amount : '✓ Yes') : '—'}</td>
              <td>${f.signature_analysis?.signature_count || 0}</td>
              <td>${f.total_field_count || f.field_count || 0}</td>
              <td>${f.pages || 1}</td>
            </tr>`).join('');
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function downloadReport(html, entityName) {
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Form-Genome-Report-${entityName.replace(/[^a-z0-9]/gi, '-')}-${Date.now()}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  console.log('[FORM GENOME] Report downloaded successfully');
}
