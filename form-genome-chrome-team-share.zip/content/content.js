// Form Genome Chrome Extension - Content Script
// Detects PDFs on the current page and finds all PDF links

// Check if current page is a PDF
const isPdfPage = () => {
  const url = window.location.href;
  return url.endsWith('.pdf') ||
         url.includes('.pdf?') ||
         url.includes('type=application/pdf') ||
         document.contentType === 'application/pdf';
};

// Find all PDF links on the page
function findPdfLinks() {
  const links = document.querySelectorAll('a[href]');
  const pdfLinks = [];

  links.forEach(link => {
    const href = link.href;
    if (href && (href.endsWith('.pdf') || href.includes('.pdf?'))) {
      // Extract filename from URL
      const urlParts = href.split('/');
      const filename = urlParts[urlParts.length - 1].split('?')[0];

      pdfLinks.push({
        url: href,
        filename: filename || 'document.pdf',
        text: link.textContent.trim() || filename
      });
    }
  });

  return pdfLinks;
}

// Helper function to safely send messages (handles extension reload)
function safeSendMessage(message) {
  try {
    chrome.runtime.sendMessage(message, (response) => {
      // Check for errors (like extension context invalidated)
      if (chrome.runtime.lastError) {
        // Extension was reloaded - silently ignore
        console.debug('Extension reloaded, ignoring message:', chrome.runtime.lastError.message);
      }
    });
  } catch (error) {
    // Extension context invalidated - silently ignore
    console.debug('Extension context invalidated:', error.message);
  }
}

// Wait for DOM to be fully ready before initial scan
function performInitialScan() {
  if (isPdfPage()) {
    safeSendMessage({
      type: 'PDF_DETECTED',
      url: window.location.href,
      isPdfPage: true
    });
  } else {
    // Send list of PDF links found on page
    const pdfLinks = findPdfLinks();
    if (pdfLinks.length > 0) {
      safeSendMessage({
        type: 'PDF_LINKS_FOUND',
        pdfs: pdfLinks,
        pageUrl: window.location.href
      });
    }
  }
}

// Perform initial scan when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', performInitialScan);
} else {
  // DOM already loaded
  performInitialScan();
}

// Listen for requests from popup to scan for PDFs
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SCAN_FOR_PDFS') {
    if (isPdfPage()) {
      sendResponse({
        isPdfPage: true,
        url: window.location.href
      });
    } else {
      const pdfLinks = findPdfLinks();
      sendResponse({
        isPdfPage: false,
        pdfs: pdfLinks,
        pageUrl: window.location.href
      });
    }
  }
  return true; // Keep channel open for async response
});

// Watch for dynamically added PDF links (for infinite scroll, pagination, etc.)
let lastPdfCount = findPdfLinks().length;

const observer = new MutationObserver(() => {
  const currentPdfs = findPdfLinks();
  if (currentPdfs.length !== lastPdfCount) {
    lastPdfCount = currentPdfs.length;
    safeSendMessage({
      type: 'PDF_LINKS_UPDATED',
      pdfs: currentPdfs,
      pageUrl: window.location.href
    });
  }
});

// Start observing for DOM changes
observer.observe(document.body, {
  childList: true,
  subtree: true
});
